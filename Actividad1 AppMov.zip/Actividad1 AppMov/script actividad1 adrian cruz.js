var cerrarCaja = button => {
    document.getElementById(button).style.display="none";
    document.getElementById(contenido).textContent="hola";
}

